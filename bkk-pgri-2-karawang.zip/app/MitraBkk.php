<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MitraBkk extends Model
{
    protected $fillable = (['nama_perusahaan','images']);
}

<?php return array (
  'back.aaaaa' => 'App\\Http\\Livewire\\Back\\Aaaaa',
  'back.seleksi-peserta' => 'App\\Http\\Livewire\\Back\\SeleksiPeserta',
);